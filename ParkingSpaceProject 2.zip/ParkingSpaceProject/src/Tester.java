import java.util.Scanner;

public class Tester {

    public static void main(String[] args)
    {
        ParkingLot parkingLot = new ParkingLot(4, "TestLot");


        parkingLot.addCar(new Car(6, 20, 1, "One"));
        parkingLot.addCar(new Car(7, 20, 3, "Two"));
        parkingLot.addCar(new Car(8, 20, 1, "Three"));
        parkingLot.addCar(new Car(9, 20, 1, "Four"));
//        for (int i = 0; i < 3; i++)
//        {
//            parkingLot.addCar(addCar());
//        }
        parkingLot.rankCars();
        parkingLot.sortCars();
        parkingLot.printCarList();

    }

    public static Car addCar()
    {
        Scanner input = new Scanner(System.in);

        System.out.println("Minutes from school?");
        int minutes = input.nextInt();

        System.out.println("City miles per gallon of car used");
        double mpg = input.nextDouble();

        System.out.println("Max num people per car");
        int peoplePerCar = input.nextInt();

        System.out.println("Identification");
        String id = input.next();
        return new Car(minutes, mpg, peoplePerCar, id);
    }

    public static String hash(String x)
    {
        return "";
    }
    public static double getDecimal()
    {
        return 0;
    }

}

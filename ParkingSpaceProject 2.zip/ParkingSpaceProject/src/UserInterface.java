import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class UserInterface extends JFrame implements ActionListener
{
    private static final int WIDTH = 750;
    private static final int HEIGHT = 500;

    public static ArrayList<ParkingLot> parkingLots = new ArrayList<ParkingLot>();
    public static ParkingLot chosenLot;

    public UserInterface()
    {
        JFrame frame = new JFrame("Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel LotPanel = new JPanel();
        LotPanel.setPreferredSize(new Dimension(WIDTH, (int)(HEIGHT*0.1)));

        frame.getContentPane().add(LotPanel, BorderLayout.NORTH);
        addLotUIHandler(LotPanel);
        
        JPanel LotEditorPanel = new JPanel();
        LotEditorPanel.setPreferredSize(new Dimension(WIDTH, (int)(HEIGHT*0.9)));
        
        frame.getContentPane().add(LotEditorPanel, BorderLayout.SOUTH);
        lotEditorUI(LotEditorPanel);
        
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args)
    {
        UserInterface ui = new UserInterface();
    }

    public static void addLot(int spaces, String name)
    {
        parkingLots.add(new ParkingLot(spaces, name));
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

    }

    private static ParkingLot getLot(String name)
    {
        ParkingLot answer = null;
        for(ParkingLot l : parkingLots)
        {
            if(l.equals(name))
                return answer = l;
        }
        return answer;
    }

    private static String[] getLotNames()
    {
        String[] answer = new String[parkingLots.size()];
        for(int i = 0; i<answer.length; i++)
        {
            answer[i] = parkingLots.get(i).toString();
        }
        return answer;
    }

    private static void addLotUIHandler(JPanel panel)
    {
        JTextField lotName = new JTextField("Parking Lot Name");
        JTextField numSpaces = new JTextField("Number of Spaces");

        panel.add(lotName, BorderLayout.CENTER);
        panel.add(numSpaces);


        JButton newLot = new JButton("Add Parking Lot");
        newLot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                addLot(Integer.parseInt(numSpaces.getText()), lotName.getText());
                System.out.println("Added " + lotName.getText() + " with " + numSpaces.getText() + " spaces");
            }
        });
        panel.add(newLot);
    }
    
    private Exception noChosenLot()
    {
        if(chosenLot==null)
            return new Exception("No Lot has been chosen");
        return null;
    }

    private static void lotEditorUI(JPanel panel)
    {
        JComboBox lots = new JComboBox(getLotNames());
        lots.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chosenLot = getLot((String)lots.getSelectedItem());
            }
        });
    }
}

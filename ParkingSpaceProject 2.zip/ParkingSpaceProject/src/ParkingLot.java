import java.util.ArrayList;
import java.util.Collections;

public class ParkingLot
{
    public int numSpots;        //number of unreserved parking spots
    public ArrayList<Car> cars = new ArrayList<Car>(); //list of cars with priority info
    public String ParkingLotName;
    public static final double MILES_WEIGHT = 1;
    public static final double MPG_WEIGHT = 0;
    public static final double PEOPLE_WEIGHT = 1;

    public ParkingLot(int numSpots, String name)
    {
        this.numSpots = numSpots;
        this.ParkingLotName = name;
    }

    public void addCar(Car c)
    {
        cars.add(c);
    }

    public void rankCars()
    {
        for (Car c: cars)
        {                                                               //the important ranking algorithm
            double rank =
                    MILES_WEIGHT*c.miles +
                    MPG_WEIGHT*c.mpg +
                    PEOPLE_WEIGHT*(c.peoplePerCar-1);
            c.setParkingRank(rank);
        }
    }

    public ArrayList<Car> sortCars()
    {
        Collections.sort(cars);
        if(cars.get(0).parkingRank-cars.get(1).parkingRank<0)
            System.out.println("Needs to be reverse");
        return this.cars;
    }

    public void printCarList()
    {
        for(Car c : cars)
        {
            System.out.println(c + " " + c.parkingRank);
        }
    }

    @Override
    public String toString() {
        return ParkingLotName;
    }
}
//insidiae123@gmail.com
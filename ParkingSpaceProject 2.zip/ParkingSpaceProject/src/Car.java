public class Car implements Comparable
{

    public double miles;      //time to PCS
    public double mpg;       //miles per gallon
    public int peoplePerCar; //number of people per car
    public String id = "";

    public double parkingRank;

    public Car()
    {
        miles = -1;
        mpg = -1;
        peoplePerCar = -1;
        id = "UNDECLARED NAME AND CAR";

    }

    public Car(double miles,double mpg, int peoplePerCar, String id)
    {
        this.miles = miles;
        this.mpg = mpg;
        this.peoplePerCar = peoplePerCar;
        this.id = id;
    }

    public void setParkingRank(double x)
    {
        parkingRank = x;
    }

    @Override
    public int compareTo(Object o) {
        try
        {
            Car two = (Car) o;
            if(this.parkingRank > two.parkingRank)
                return -1;
            return 1;
        }
        catch(Exception e)
        {
            e = new Exception("Cannot cast 'o' to type Car");
            return 0;
        }
    }

    public String toString()
    {
        return id;
    }
}

import java.util.Scanner;

public class Tester {

    public static void main(String[] args)
    {
        ParkingLot parkingLot = new ParkingLot(3);

        for (int i = 0; i < 3; i++)
        {
            parkingLot.addCar(addCar());
        }
        parkingLot.sortCars();
    }

    public static Car addCar()
    {
        Car answer = new Car();
        Scanner input = new Scanner(System.in);

        System.out.println("Minutes from school?");
        answer.minutes = input.nextInt();

        System.out.println("City miles per gallon of car used");
        answer.mpg = input.nextDouble();

        System.out.println("Max num people per car");
        answer.peoplePerCar = input.nextInt();
        return answer;
    }

}

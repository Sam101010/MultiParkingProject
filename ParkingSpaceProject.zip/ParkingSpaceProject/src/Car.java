public class Car implements Comparable
{

    public int minutes;      //time to PCS
    public double mpg;       //miles per gallon
    public int peoplePerCar; //number of people per car
    public String id;

    public double parkingRank;

    public Car()
    {

    }

    public Car(int minutes,double mpg, int peoplePerCar)
    {
        this.minutes = minutes;
        this.mpg = mpg;
        this.peoplePerCar = peoplePerCar;
    }

    public void setParkingRank(double x)
    {
        parkingRank = x;
    }

    @Override
    public int compareTo(Object o) {
        try
        {
            Car two = (Car) o;
            if(this.parkingRank > two.parkingRank)
                return 1;
            return -1;
        }
        catch(Exception e)
        {
            e = new Exception("Cannot cast 'o' to type Car");
            return 0;
        }
    }
}

import java.util.ArrayList;
import java.util.Collections;

public class ParkingLot
{
    public int numSpots;        //number of unreserved parking spots
    public ArrayList<Car> cars; //list of cars with priority info
    public static final int MINUTES_WEIGHT = 1;
    public static final double MPG_WEIGHT = -1;
    public static final int PEOPLE_WEIGHT = 10;

    public ParkingLot(int numSpots)
    {
        this.numSpots = numSpots;
    }

    public void addCar(Car c)
    {
        cars.add(c);
    }

    public void rankCars()
    {
        for (Car c: cars)
        {
            double rank =
                    MINUTES_WEIGHT*c.minutes +
                    MPG_WEIGHT*c.mpg +
                    PEOPLE_WEIGHT*c.peoplePerCar;
            c.setParkingRank(rank);
        }
    }

    public ArrayList<Car> sortCars()
    {
        Collections.sort(cars);
        if(cars.get(0).parkingRank-cars.get(1).parkingRank<0)
            System.out.println("Needs to be reverse");
        return this.cars;
    }

}
//insidiae123@gmail.com